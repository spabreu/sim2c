?package(sim2c):needs=X11|text|vc|wm section=Apps/see-menu-manual\
  title="sim2c" command="/usr/bin/sim2c"
