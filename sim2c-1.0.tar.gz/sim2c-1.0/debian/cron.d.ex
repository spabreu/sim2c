#
# Regular cron jobs for the sim2c package
#
0 4	* * *	root	sim2c_maintenance
