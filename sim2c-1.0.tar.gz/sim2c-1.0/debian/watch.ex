# Example watch control file for uscan
# Rename this file to "watch" and then you can run the "uscan" command
# to check for upstream updates and more.
# Site		Directory		Pattern			Version	Script
sunsite.unc.edu	/pub/Linux/Incoming	sim2c-(.*)\.tar\.gz	debian	uupdate
