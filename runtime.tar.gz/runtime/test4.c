#include <stdio.h>

// == Global data =============================================================

#define W  * 4
#define KB * 1024
#define MB KB KB

#define DATA_SZ   8 MB
#define HEAP_SZ  16 MB
#define STACK_SZ 16 MB

union {
  int mem[0];
  struct {
    int m_x;
    int m_xpto[20];
  } named;
  struct {
    int z_data[DATA_SZ];
    int z_heap[HEAP_SZ];
    int z_stack[STACK_SZ];
  } zone;
} global;

#define MEM   global.mem
#define DATA  global.zone.z_data
#define HEAP  global.zone.z_heap
#define STACK global.zone.z_stack

int *SP = STACK+STACK_SZ;
int *FP = 0;
int  SR;
void *PC;				// (unused)

// -- Names for global variables ----------------------------------------------

#define GV_x ((int *) &global.named.m_x - (int *) &global.named)
#define GV_xpto ((int *) &global.named.m_xpto - (int *) &global.named)

// == Program =================================================================

int main (int argc, char *argv[])
{
  int i;

// -- Initialization ----------------------------------------------------------
  global.named.m_x = 123;
  for (i=0; i<20; ++i) global.named.m_xpto[i] = 0;

// -- Library -----------------------------------------------------------------

	goto lib_init;			// skip library code!

print_int:				// print_int (int) -> ()
	printf ("%d\n", SP[1]);
	goto * ((void *) *SP++);

print_char:				// print_char (int) -> ()
	putchar (SP[1]);
	goto * ((void *) *SP++);

read_int:				// read_int () -> int
	scanf ("%d", &SP[1]);
	goto * ((void *) *SP++);

read_char:				// read_char () -> int
	SP[1] = getchar ();
	goto * ((void *) *SP++);

halt:					// halt () -> ()
	return 0;

dump_regs:				// dump_regs () -> ()
	{
	  printf ("-- Register dump --\n");
	  printf ("SP = 0x%x (%d)\n", (int) SP, (int) SP);
	  printf ("FP = 0x%x (%d)\n", (int) FP, (int) FP);
	  printf ("SR = 0x%x (%d)\n", (int) SR, (int) SR);
	  printf ("PC = (unused)\n");
	}
	goto * ((void *) *SP++);

dump_stack:				// dump_stack () -> ()
	{
	  printf ("-- Stack dump --\n");
	}
	goto * ((void *) *SP++);

stack_trace:				// stack_trace () -> ()
	{
	  printf ("-- Stack trace --\n");
	}
	goto * ((void *) *SP++);

lib_init:
	{
	  // (declarations for function ) (print_int);
	  // (declarations for function ) (print_char);
	  // (declarations for function ) (read_int);
	  // (declarations for function ) (read_char);
	  // (declarations for function ) (halt);
	  // (declarations for function ) (dump_regs);
	  // (declarations for function ) (dump_stack);
	  // (declarations for function ) (stack_trace);
	}

// -- Start execution ---------------------------------------------------------
  *--SP = (int) &&L_exit_program; // Save return address for main program
  goto program;			// start kicking...
L_exit_program:			// Return here, and...
  exit (0);			// quit.
  

// -- Instructions ------------------------------------------------------------
program:
	*--SP = 0;		// PUSH 0
	{ int N = *SP; MEM[*SP]=(int) FP; FP=SP; SP -= N; } // LINK
	*--SP = 0;		// PUSH 0
	*--SP = (int) &&read_int;		// PUSH read_int
	{ void *C = (void *) *SP; *SP=(int)&&P_6; goto *C; } // CALL
P_6:	*--SP = 2;		// PUSH 2
	SP[1] = SP[1] * SP[0]; ++SP;	// MUL
	*--SP = (int) &&print_int;		// PUSH print_int
	{ void *C = (void *) *SP; *SP=(int)&&P_10; goto *C; } // CALL
P_10:	SP=FP; FP=(int *)MEM[*SP++];	// UNLINK
	goto * ((void *)*SP++);		// JUMP

}

